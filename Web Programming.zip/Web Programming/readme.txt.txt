Mohammed Ali Al Hassani (1072797)
Kevin John (1072928)

Install npm dependencies 
run node requests.js to create databse from cmd
run node deliveryrequests.js to start from cmd

open browser 
go to
http://localhost:3000/